import numpy as np
import matplotlib.pyplot as plt

# Datos de edades
edades = [25, 30, 35, 40, 45, 50, 55]

# Cálculo de estadísticas con NumPy
media = np.mean(edades)
mediana = np.median(edades)
varianza = np.var(edades)
desviacion_estandar = np.std(edades)

# Mostrar resultados estadísticos
print("--- Estadísticas Completa ---")
print(f"Edades: {edades}")
print(f"Media: {media:.2f}")
print(f"Mediana: {mediana:.2f}")
print(f"Varianza: {varianza:.2f}")
print(f"Desviación estándar: {desviacion_estandar:.2f}")

# Visualización mejorada
plt.figure(figsize=(12, 6))

# Gráfico de distribución con medidas estadísticas
plt.subplot(1, 2, 1)
bars = plt.bar(range(len(edades)), edades, color='skyblue', alpha=0.7)
plt.axhline(media, color='red', linestyle='-', linewidth=2, label=f'Media: {media:.1f}')
plt.axhline(mediana, color='green', linestyle='--', linewidth=2, label=f'Mediana: {mediana:.1f}')
plt.axhline(media + desviacion_estandar, color='blue', linestyle=':', label=f'±1σ: {desviacion_estandar:.1f}')
plt.axhline(media - desviacion_estandar, color='blue', linestyle=':')
plt.title('Distribución de Edades con Medidas Estadísticas')
plt.xlabel('Individuos')
plt.ylabel('Edad (años)')
plt.xticks(range(len(edades)), [f"P{i+1}" for i in range(len(edades))])
plt.legend()

# Gráfico de densidad con distribución normal teórica
plt.subplot(1, 2, 2)
counts, bins, _ = plt.hist(edades, bins=5, density=True, alpha=0.5, color='orange')

# Añadir curva normal teórica
from scipy.stats import norm
xmin, xmax = plt.xlim()
x = np.linspace(xmin, xmax, 100)
p = norm.pdf(x, media, desviacion_estandar)
plt.plot(x, p, 'k', linewidth=2, label='Distribución normal teórica')

plt.axvline(media, color='red', linestyle='-', label=f'Media')
plt.axvline(media + desviacion_estandar, color='blue', linestyle=':', label=f'±1σ')
plt.axvline(media - desviacion_estandar, color='blue', linestyle=':')
plt.title('Distribución de Probabilidad')
plt.xlabel('Edad (años)')
plt.ylabel('Densidad')
plt.legend()

plt.tight_layout()
plt.show()